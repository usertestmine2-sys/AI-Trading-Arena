import { Portfolio } from "../../types/trading";
import { PortfolioSnapshot } from "../../types/portfolio";

export class Snapshotter {
  static createSnapshot(portfolio: Portfolio): PortfolioSnapshot {
    const totalValue = portfolio.balance + portfolio.positions.reduce((acc, pos) => acc + (pos.quantity * pos.averagePrice), 0);
    return {
      timestamp: new Date(),
      balance: portfolio.balance,
      holdings: portfolio.positions,
      totalValue
    };
  }
}
