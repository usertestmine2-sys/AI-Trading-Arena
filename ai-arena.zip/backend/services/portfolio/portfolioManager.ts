import { Position, Portfolio } from "../../types/trading";
import { PortfolioSnapshot } from "../../types/portfolio";

export class PortfolioManager {
  private portfolio: Portfolio;
  private history: PortfolioSnapshot[] = [];

  constructor(initialBalance: number) {
    this.portfolio = { balance: initialBalance, positions: [] };
  }

  getHoldings(): Position[] {
    return this.portfolio.positions;
  }

  getCash(): number {
    return this.portfolio.balance;
  }

  updatePosition(symbol: string, quantity: number, price: number) {
    const existingPos = this.portfolio.positions.find(p => p.symbol === symbol);
    if (existingPos) {
      existingPos.quantity += quantity;
      existingPos.averagePrice = (existingPos.averagePrice * existingPos.quantity + price * quantity) / (existingPos.quantity + quantity);
    } else {
      this.portfolio.positions.push({ symbol, quantity, averagePrice: price });
    }
  }

  getHistory(): PortfolioSnapshot[] {
    return this.history;
  }
}
