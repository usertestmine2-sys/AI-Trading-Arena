import { PortfolioSnapshot, PortfolioPerformance } from "../../types/portfolio";

export class AnalyticsEngine {
  static calculateReturns(history: PortfolioSnapshot[]): number {
    if (history.length < 2) return 0;
    const first = history[0].totalValue;
    const last = history[history.length - 1].totalValue;
    return (last - first) / first;
  }

  static calculatePerformance(history: PortfolioSnapshot[]): PortfolioPerformance {
    // Simplified metrics
    return {
      returns: this.calculateReturns(history),
      volatility: 0,
      sharpeRatio: 0,
      drawdown: 0
    };
  }
}
