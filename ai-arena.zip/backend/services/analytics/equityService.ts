export interface EquityPoint {
  date: string;
  value: number;
}

export class EquityService {
  private equityCurve: EquityPoint[] = [
    { date: '2023-01-01', value: 100000 },
    { date: '2023-02-01', value: 105000 },
    { date: '2023-03-01', value: 102000 },
    { date: '2023-04-01', value: 110000 }
  ];

  async getEquityCurve(): Promise<EquityPoint[]> {
    return this.equityCurve;
  }
}
