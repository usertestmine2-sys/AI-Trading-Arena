import { AnalyticsMetrics, DashboardData } from "../../types/analytics";
import { MetricsEngine } from "./metrics";
import { TradeService } from "../trading/tradeService";

export class DashboardService {
  private tradeService = new TradeService();

  async getDashboardData(): Promise<DashboardData> {
    const trades = await this.tradeService.getTrades();
    const tradeData = trades.map(t => ({ profit: t.price * t.quantity * 0.01 })); // Simplified for now
    
    const realMetrics = {
      winRate: MetricsEngine.calculateWinRate(tradeData),
      sharpeRatio: MetricsEngine.calculateSharpeRatio(tradeData.map(t => t.profit)),
      sortinoRatio: MetricsEngine.calculateSortinoRatio(tradeData.map(t => t.profit)),
      maxDrawdown: MetricsEngine.calculateDrawdown(tradeData.map(t => t.profit)),
      totalTrades: trades.length,
      totalProfit: tradeData.reduce((acc, val) => acc + val.profit, 0)
    };

    return {
      aiPerformance: realMetrics,
      strategyPerformance: realMetrics,
      tradeAnalytics: {},
      portfolioAnalytics: {}
    };
  }
}

