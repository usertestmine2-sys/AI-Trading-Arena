import { MetricsEngine } from "./metrics";
import { Trade } from "../../types/trading";

export class TradeAnalyticsService {
  private trades: Trade[] = [];

  async recordTrade(trade: Trade) {
    this.trades.push(trade);
  }
}

export class TradeAnalytics {
  static analyzeTrades(trades: Trade[]): any {
    const tradeData = trades.map(t => ({ profit: t.price * t.quantity * 0.01 }));
    return {
      winRate: MetricsEngine.calculateWinRate(tradeData),
      totalTrades: trades.length
    };
  }
}

