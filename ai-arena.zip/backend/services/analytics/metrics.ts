export class MetricsEngine {
  static calculateWinRate(trades: { profit: number }[]): number {
    if (trades.length === 0) return 0;
    const wins = trades.filter(t => t.profit > 0).length;
    return wins / trades.length;
  }

  static calculateDrawdown(equityCurve: number[]): number {
    if (equityCurve.length === 0) return 0;
    let maxDrawdown = 0;
    let peak = equityCurve[0];
    for (const value of equityCurve) {
      if (value > peak) peak = value;
      const drawdown = (peak - value) / peak;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    }
    return maxDrawdown;
  }

  // Simplified Sharpe/Sortino
  static calculateSharpeRatio(returns: number[]): number {
    if (returns.length < 2) return 0;
    const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
    const stdDev = Math.sqrt(returns.map(r => Math.pow(r - mean, 2)).reduce((a, b) => a + b, 0) / (returns.length - 1));
    return stdDev === 0 ? 0 : mean / stdDev;
  }

  static calculateSortinoRatio(returns: number[]): number {
    if (returns.length < 2) return 0;
    const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
    const downsideReturns = returns.filter(r => r < 0);
    const downsideStdDev = downsideReturns.length < 2 ? 0 : Math.sqrt(downsideReturns.map(r => Math.pow(r, 2)).reduce((a, b) => a + b, 0) / downsideReturns.length);
    return downsideStdDev === 0 ? 0 : mean / downsideStdDev;
  }
}
