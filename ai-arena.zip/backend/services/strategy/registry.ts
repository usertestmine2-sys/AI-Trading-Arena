import { Strategy, StrategyStatus, RiskLevel, MarketType } from "../../types/strategy";
import { logger } from "../../utils/logger";

export class StrategyRegistry {
  private strategies: Map<string, Strategy> = new Map();

  constructor() {
    this.initializeStrategies();
  }

  private initializeStrategies() {
    // Generate 20 distinct strategies
    for (let i = 1; i <= 20; i++) {
      const strategy: Strategy = {
        id: `strat-${i.toString().padStart(3, '0')}`,
        name: `Strategy ${i}`,
        description: `This is the description for strategy ${i}`,
        riskLevel: i % 3 === 0 ? RiskLevel.HIGH : i % 2 === 0 ? RiskLevel.MEDIUM : RiskLevel.LOW,
        timeframe: i % 4 === 0 ? '1h' : i % 2 === 0 ? '5m' : '1d',
        marketType: i % 3 === 0 ? MarketType.EQUITY : i % 2 === 0 ? MarketType.FOREX : MarketType.CRYPTO,
        entryConditions: ['indicator_a > indicator_b'],
        exitConditions: ['indicator_a < indicator_b'],
        requiredIndicators: ['RSI', 'MACD'],
        aiCompatibility: i % 2 === 0,
        paperTradingSupport: true,
        version: '1.0.0',
        status: StrategyStatus.ENABLED,
        priority: i,
        dependencies: [],
        executionInterface: 'standard',
        performanceMetadata: {
          winRate: 0.5 + (i * 0.01),
          profitFactor: 1.2 + (i * 0.05)
        },
        healthStatus: 'healthy'
      };
      this.strategies.set(strategy.id, strategy);
    }
    logger.info(`Initialized ${this.strategies.size} strategies.`);
  }

  getStrategy(id: string): Strategy | undefined {
    return this.strategies.get(id);
  }

  getAllStrategies(): Strategy[] {
    return Array.from(this.strategies.values());
  }

  enableStrategy(id: string) {
    const strategy = this.strategies.get(id);
    if (strategy) {
      strategy.status = StrategyStatus.ENABLED;
      logger.info(`Strategy ${id} enabled.`);
    }
  }

  disableStrategy(id: string) {
    const strategy = this.strategies.get(id);
    if (strategy) {
      strategy.status = StrategyStatus.DISABLED;
      logger.info(`Strategy ${id} disabled.`);
    }
  }
}
