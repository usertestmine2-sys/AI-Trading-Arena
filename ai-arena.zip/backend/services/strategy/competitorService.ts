export interface Competitor {
  id: string;
  name: string;
  model: string;
  winRate: number;
  accuracy: number;
  currentStrategy: string;
  status: string;
}

export class CompetitorService {
  private competitors: Competitor[] = [
    { id: '1', name: 'AlphaBot', model: 'GPT-4o', winRate: 72, accuracy: 88, currentStrategy: 'Momentum', status: 'thinking' },
    { id: '2', name: 'BetaTrade', model: 'Claude 3.5', winRate: 68, accuracy: 85, currentStrategy: 'Mean Reversion', status: 'active' },
    { id: '3', name: 'GammaQuant', model: 'Gemini 1.5', winRate: 75, accuracy: 91, currentStrategy: 'Arbitrage', status: 'idle' }
  ];

  async getCompetitors(): Promise<Competitor[]> {
    return this.competitors;
  }
}
