import { Strategy } from "../../types/strategy";
import { logger } from "../../utils/logger";

export class StrategyValidator {
  static validate(strategy: Strategy): boolean {
    if (!strategy.id || !strategy.name || !strategy.entryConditions.length || !strategy.exitConditions.length) {
      logger.error(`Invalid strategy: ${strategy.id}`);
      return false;
    }
    return true;
  }
}
