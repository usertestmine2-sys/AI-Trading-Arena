import { Strategy } from "../../types/strategy";
import { logger } from "../../utils/logger";
import { StrategyValidator } from "./validator";

export class StrategyLoader {
  static async load(config: any): Promise<Strategy> {
    // Simulate loading from a external source
    const strategy: Strategy = config;
    if (StrategyValidator.validate(strategy)) {
      logger.info(`Strategy ${strategy.id} loaded successfully.`);
      return strategy;
    }
    throw new Error(`Failed to load strategy: ${strategy.id}`);
  }
}
