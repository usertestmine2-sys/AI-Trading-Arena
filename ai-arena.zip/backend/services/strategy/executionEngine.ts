import { StrategyRegistry } from "./registry";
import { AIEngineManager } from "../ai/engineManager";
import { ExecutionEngine as TradingExecutionEngine } from "../trading/executionEngine";
import { RiskService } from "../trading/riskService";
import { PortfolioService } from "../trading/portfolioService";
import { TradeAnalyticsService } from "../analytics/tradeAnalytics";
import { WebSocketEngine } from "../websocket/engine";
import { logger } from "../../utils/logger";
import { Order } from "../../types/trading";

export class StrategyExecutionEngine {
  constructor(
    private registry: StrategyRegistry,
    private aiManager: AIEngineManager,
    private tradingEngine: TradingExecutionEngine,
    private riskService: RiskService,
    private portfolioService: PortfolioService,
    private analytics: TradeAnalyticsService,
    private websocket: WebSocketEngine
  ) {}

  async executeStrategy(strategyId: string, marketContext: any) {
    try {
      const strategy = this.registry.getStrategy(strategyId);
      if (!strategy || strategy.status !== 'enabled') {
        throw new Error(`Strategy ${strategyId} not found or disabled.`);
      }

      logger.info(`Executing strategy: ${strategy.name}`);

      // 1. AI Decision
      const decision = await this.aiManager.generate(strategyId, JSON.stringify(marketContext));
      
      // Assume decision format is { side: 'buy' | 'sell', quantity: number, symbol: string }
      const order: Order = JSON.parse(decision);

      // 2. Risk Validation
      if (!this.riskService.validateOrder(order, this.portfolioService.getPortfolio())) {
        throw new Error("Order failed risk validation.");
      }

      // 3. Execute
      const trade = await this.tradingEngine.executeOrder(order, marketContext.price);

      // 4. Update Portfolio
      this.portfolioService.updatePortfolio(trade);

      // 5. Analytics
      await this.analytics.recordTrade(trade);

      // 6. Notify
      this.websocket.broadcast('trade_executed', trade);

      logger.info(`Strategy ${strategy.name} executed successfully.`);
      return trade;

    } catch (error) {
      logger.error(`Error executing strategy ${strategyId}`, error);
      this.websocket.broadcast('execution_error', { strategyId, error: error instanceof Error ? error.message : 'Unknown' });
      throw error;
    }
  }
}
