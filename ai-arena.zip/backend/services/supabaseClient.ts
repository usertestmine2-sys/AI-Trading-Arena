import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { config } from "../config/config";

const supabaseUrl = config.supabaseUrl;
const supabaseAnonKey = config.supabaseAnonKey;
const supabaseServiceRoleKey = config.supabaseServiceRoleKey;

if (!supabaseUrl || !supabaseAnonKey || !supabaseServiceRoleKey) {
  console.warn("Warning: Supabase credentials missing. Supabase client initialized in fallback mode.");
}

let supabase: SupabaseClient | null = null;
let supabaseAdmin: SupabaseClient | null = null;

export const getSupabase = (): SupabaseClient => {
  if (!supabase) {
    supabase = createClient(supabaseUrl, supabaseAnonKey);
  }
  return supabase;
};

export const getSupabaseAdmin = (): SupabaseClient => {
  if (!supabaseAdmin) {
    supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);
  }
  return supabaseAdmin;
};

export const checkSupabaseConnection = async (): Promise<boolean> => {
  try {
    const { data, error } = await getSupabase().from("dummy_table_to_check_connection").select("*", { count: "exact", head: true });
    // Expect an error since the table likely doesn't exist, but check for 401 or network issues
    if (error && error.code === "PGRST116") return true; // Table doesn't exist is fine, just means connected
    if (error && error.code === "401") return false;
    return true;
  } catch (err) {
    return false;
  }
};
