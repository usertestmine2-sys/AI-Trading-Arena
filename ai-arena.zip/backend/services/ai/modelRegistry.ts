import { AIModel, AIProvider } from "../../types/ai";

export const MODELS: AIModel[] = [
  { id: "gemini-flash-latest", name: "Gemini Flash", provider: AIProvider.GOOGLE, isPaid: false, description: "Fast and versatile" },
  { id: "gemini-3.1-flash-lite", name: "Gemini Flash Lite", provider: AIProvider.GOOGLE, isPaid: false, description: "Lightweight and fast" },
  { id: "gemini-3.1-pro-preview", name: "Gemini Pro", provider: AIProvider.GOOGLE, isPaid: true, description: "Advanced reasoning" },
  { id: "gemini-2.5-flash-image", name: "Gemini Flash Image", provider: AIProvider.GOOGLE, isPaid: true, description: "General image" },
  { id: "gemini-3.1-flash-image", name: "Gemini Flash Image 3.1", provider: AIProvider.GOOGLE, isPaid: true, description: "High-quality image" },
  { id: "gemini-3-pro-image", name: "Gemini Pro Image", provider: AIProvider.GOOGLE, isPaid: true, description: "Pro image generation" },
  { id: "gemini-3.1-flash-live-preview", name: "Gemini Flash Live", provider: AIProvider.GOOGLE, isPaid: false, description: "Real-time" },
  { id: "gemini-3.5-live-translate-preview", name: "Gemini Live Translate", provider: AIProvider.GOOGLE, isPaid: false, description: "Real-time translation" },
  { id: "gemini-3.1-flash-tts-preview", name: "Gemini TTS", provider: AIProvider.GOOGLE, isPaid: false, description: "Text-to-speech" },
  { id: "veo-3.1-lite-generate-preview", name: "Veo Lite", provider: AIProvider.GOOGLE, isPaid: true, description: "General video" },
  { id: "lyria-3-clip-preview", name: "Lyria Clip", provider: AIProvider.GOOGLE, isPaid: true, description: "Short music clip" },
  { id: "lyria-3-pro-preview", name: "Lyria Pro", provider: AIProvider.GOOGLE, isPaid: true, description: "Full-length music" },
  { id: "gemini-embedding-2-preview", name: "Gemini Embedding", provider: AIProvider.GOOGLE, isPaid: false, description: "Embedding" },
  { id: "veo-3.1-generate-preview", name: "Veo", provider: AIProvider.GOOGLE, isPaid: true, description: "High-quality video" },
  { id: "openai/gpt-4o", name: "GPT-4o", provider: AIProvider.OPENROUTER, isPaid: true, description: "Advanced OpenAI model" },
  { id: "anthropic/claude-3.5-sonnet", name: "Claude 3.5 Sonnet", provider: AIProvider.OPENROUTER, isPaid: true, description: "Advanced Anthropic model" },
];

export const getModelById = (id: string): AIModel | undefined => MODELS.find(m => m.id === id);
