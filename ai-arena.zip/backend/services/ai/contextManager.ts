export class ContextManager {
  private memory: Map<string, any[]> = new Map();

  addContext(sessionId: string, item: any) {
    const history = this.memory.get(sessionId) || [];
    history.push(item);
    this.memory.set(sessionId, history);
  }

  getContext(sessionId: string): any[] {
    return this.memory.get(sessionId) || [];
  }

  clearContext(sessionId: string) {
    this.memory.delete(sessionId);
  }
}
