import axios from 'axios';
import { logger } from '../../utils/logger';

export class OpenRouterService {
  private apiKey: string;
  private baseUrl = 'https://openrouter.ai/api/v1';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async generate(model: string, prompt: string, config?: any, retries = 3): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        {
          model,
          messages: [{ role: 'user', content: prompt }],
          ...config
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'HTTP-Referer': process.env.APP_URL || 'http://localhost:3000',
            'X-Title': 'AI Arena',
          },
          timeout: 30000,
        }
      );

      const { usage, choices } = response.data;
      logger.info(`OpenRouter usage: ${JSON.stringify(usage)}`);
      
      return choices[0].message.content;
    } catch (error: any) {
      if (retries > 0 && error.response?.status === 429) {
        logger.warn(`OpenRouter rate limited, retrying in 2 seconds...`);
        await new Promise(resolve => setTimeout(resolve, 2000));
        return this.generate(model, prompt, config, retries - 1);
      }
      logger.error('OpenRouter generation failed', error);
      throw error;
    }
  }
}
