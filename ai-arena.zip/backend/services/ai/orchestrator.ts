import { AIEngineManager } from "./engineManager";
import { UsageTracker } from "./monitoring";
import { PromptManager } from "./promptManager";

export class AIOrchestrator {
  private engine: AIEngineManager;

  constructor() {
    this.engine = new AIEngineManager();
  }

  async processRequest(modelId: string, template: string, data: Record<string, any>, context: any[] = []) {
    const prompt = PromptManager.buildPrompt(template, data);
    
    // In a real scenario, we'd handle queueing, retries, timeouts, and context memory here
    const startTime = Date.now();
    try {
      const response = await this.engine.generate(modelId, prompt);
      
      const duration = Date.now() - startTime;
      UsageTracker.logUsage(modelId, 100, 50); // Dummy tokens
      
      return {
        success: true,
        data: response,
        meta: { duration, modelId }
      };
    } catch (error) {
      console.error(`Orchestrator error for ${modelId}:`, error);
      return { success: false, error: "AI processing failed" };
    }
  }
}
