import { GoogleGenAI } from "@google/genai";
import { MODELS, getModelById } from "./modelRegistry";
import { OpenRouterService } from "./openrouter";
import { AIProvider } from "../../types/ai";
import { logger } from "../../utils/logger";

export class AIEngineManager {
  private ai: GoogleGenAI;
  private openRouter: OpenRouterService;

  constructor() {
    this.ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY!,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
    });
    this.openRouter = new OpenRouterService(process.env.OPENROUTER_API_KEY!);
  }

  async generate(modelId: string, prompt: string, config?: any) {
    const model = getModelById(modelId);
    if (!model) throw new Error("Model not found");

    try {
      if (model.provider === AIProvider.OPENROUTER) {
        return await this.openRouter.generate(model.id, prompt, config);
      }
      return await this.ai.models.generateContent({
        model: model.id,
        contents: prompt,
        config
      });
    } catch (error) {
      logger.error(`Error generating with model ${modelId}`, error);
      // Fallback Logic
      if (model.provider !== AIProvider.GOOGLE || modelId !== 'gemini-flash-latest') {
        logger.info(`Falling back to gemini-flash-latest for ${modelId}`);
        return this.generate('gemini-flash-latest', prompt, config);
      }
      throw error;
    }
  }
}
