import { Position, Portfolio, Trade } from "../../types/trading";

export class PortfolioService {
  private portfolio: Portfolio = { balance: 100000, positions: [] };

  updatePortfolio(trade: Trade) {
    const cost = trade.price * trade.quantity;
    if (trade.orderId) { // Logic to differentiate Buy/Sell
      // This is very simplified, would need order side info
      this.portfolio.balance -= cost;
      
      const existingPos = this.portfolio.positions.find(p => p.symbol === trade.symbol);
      if (existingPos) {
        existingPos.quantity += trade.quantity;
      } else {
        this.portfolio.positions.push({ symbol: trade.symbol, quantity: trade.quantity, averagePrice: trade.price });
      }
    }
  }

  getPortfolio(): Portfolio {
    return this.portfolio;
  }
}
