import { Trade } from "../../types/trading";
import { TradeAnalyticsService } from "../analytics/tradeAnalytics";

export class TradeService {
  private trades: Trade[] = [];
  private analyticsService = new TradeAnalyticsService();

  async recordTrade(trade: Trade) {
    this.trades.push(trade);
    await this.analyticsService.recordTrade(trade);
  }

  async getTrades() {
    return this.trades;
  }

  async getTradeHistory() {
    return this.trades;
  }
}
