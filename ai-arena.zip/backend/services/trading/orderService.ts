import { Order, OrderStatus } from "../../types/trading";
import { randomUUID } from "crypto";

export class OrderService {
  private orders: Order[] = [];

  async createOrder(orderData: Omit<Order, 'id' | 'status' | 'timestamp'>): Promise<Order> {
    const order: Order = {
      ...orderData,
      id: randomUUID(),
      status: 'pending',
      timestamp: new Date(),
    };
    this.orders.push(order);
    return order;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.find(o => o.id === id);
  }

  async updateOrderStatus(id: string, status: OrderStatus): Promise<void> {
    const order = this.orders.find(o => o.id === id);
    if (order) order.status = status;
  }
}
