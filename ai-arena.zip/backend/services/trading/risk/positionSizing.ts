export class PositionSizing {
  static calculatePositionSize(capital: number, riskPerTrade: number, stopLossDistance: number): number {
    const riskAmount = capital * riskPerTrade;
    return riskAmount / stopLossDistance;
  }
}
