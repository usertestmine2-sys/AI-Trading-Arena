import { RiskLimits } from "../../../types/risk";
import { Position } from "../../../types/trading";
import { PositionSizing } from "./positionSizing";
import { LimitManager } from "./limits";
import { PortfolioRisk } from "./portfolioRisk";

export class RiskEngine {
  private limits: RiskLimits;

  constructor(limits: RiskLimits) {
    this.limits = limits;
  }

  validateTrade(capital: number, positions: Position[], dailyPnL: number, orderSize: number): boolean {
    if (!LimitManager.checkDailyLoss(dailyPnL, this.limits)) return false;
    
    const currentExposure = PortfolioRisk.calculateTotalExposure(positions);
    if (!LimitManager.checkExposure(currentExposure + orderSize, capital, this.limits)) return false;

    return true;
  }
}
