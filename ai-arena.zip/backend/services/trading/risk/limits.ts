import { RiskLimits } from "../../../types/risk";

export class LimitManager {
  static checkDailyLoss(dailyPnL: number, limits: RiskLimits): boolean {
    return dailyPnL > -limits.maxDailyLoss;
  }

  static checkExposure(currentExposure: number, totalCapital: number, limits: RiskLimits): boolean {
    return (currentExposure / totalCapital) <= limits.maxExposure;
  }
}
