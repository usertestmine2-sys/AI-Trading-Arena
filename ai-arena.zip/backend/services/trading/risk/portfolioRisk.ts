import { Position } from "../../../types/trading";

export class PortfolioRisk {
  static calculateTotalExposure(positions: Position[]): number {
    return positions.reduce((acc, pos) => acc + (pos.quantity * pos.averagePrice), 0);
  }
}
