import { Order, Portfolio } from "../../types/trading";
import { RiskEngine } from "./risk/engine";

export class RiskService {
  private engine: RiskEngine;

  constructor() {
    this.engine = new RiskEngine({
      maxDailyLoss: 5000,
      maxDrawdown: 10000,
      maxPositionSize: 0.1,
      maxExposure: 0.5,
    });
  }

  validateOrder(order: Order, portfolio: Portfolio): boolean {
    const orderSize = (order.price || 0) * order.quantity;
    return this.engine.validateTrade(portfolio.balance, portfolio.positions, 0, orderSize);
  }
}
