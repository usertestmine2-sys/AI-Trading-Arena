import { Order, Trade } from "../../types/trading";
import { randomUUID } from "crypto";

export class ExecutionEngine {
  async executeOrder(order: Order, currentPrice: number): Promise<Trade> {
    // Apply simple slippage: 0.1%
    const slippage = 0.001;
    const executedPrice = order.side === 'buy' ? currentPrice * (1 + slippage) : currentPrice * (1 - slippage);
    
    return {
      id: randomUUID(),
      orderId: order.id,
      symbol: order.symbol,
      price: executedPrice,
      quantity: order.quantity,
      timestamp: new Date(),
    };
  }
}
