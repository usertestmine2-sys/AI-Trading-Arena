import { MarketService } from "./marketService";

export class Scanner {
  private marketService: MarketService;

  constructor(marketService: MarketService) {
    this.marketService = marketService;
  }

  async scanSymbols(criteria: any) {
    const data = await this.marketService.getMarketData();
    let results = data as any[];

    if (criteria.minVolume) {
      results = results.filter(item => item.volume >= criteria.minVolume);
    }
    if (criteria.minPrice) {
      results = results.filter(item => item.price >= criteria.minPrice);
    }
    if (criteria.minChange) {
      results = results.filter(item => item.change >= criteria.minChange);
    }
    
    return results;
  }
}
