export class SectorService {
  private sectors = [
    { name: 'Technology', performance: 2.5, volume: 1500000 },
    { name: 'Finance', performance: -1.2, volume: 800000 },
    { name: 'Healthcare', performance: 0.8, volume: 600000 },
    { name: 'Crypto', performance: 5.4, volume: 5000000 }
  ];

  async getSectors() {
    return this.sectors;
  }

  async getSectorPerformance(sectorName: string) {
    return this.sectors.find(s => s.name === sectorName) || null;
  }
}
