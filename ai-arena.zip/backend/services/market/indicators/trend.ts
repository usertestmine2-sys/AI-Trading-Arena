import { SMA, EMA, VWAP } from 'technicalindicators';

export const calculateSMA = (prices: number[], period: number) => {
  return SMA.calculate({ period, values: prices });
};

export const calculateEMA = (prices: number[], period: number) => {
  return EMA.calculate({ period, values: prices });
};

export const calculateVWAP = (prices: number[], volumes: number[], high: number[], low: number[], close: number[]) => {
  return VWAP.calculate({ high, low, close, volume: volumes });
};

export const calculateSuperTrend = (high: number[], low: number[], close: number[], period: number, multiplier: number) => {
  return []; // Placeholder: SuperTrend implementation is specific
};
