import { RSI, MACD, ADX } from 'technicalindicators';

export const calculateRSI = (prices: number[], period: number) => {
  return RSI.calculate({ period, values: prices });
};

export const calculateMACD = (prices: number[], fastPeriod: number, slowPeriod: number, signalPeriod: number) => {
  return MACD.calculate({ values: prices, fastPeriod, slowPeriod, signalPeriod, SimpleMAOscillator: false, SimpleMASignal: false });
};

export const calculateADX = (high: number[], low: number[], close: number[], period: number) => {
  return ADX.calculate({ high, low, close, period });
};
