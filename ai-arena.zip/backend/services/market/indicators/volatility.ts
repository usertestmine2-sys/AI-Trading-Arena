import { ATR, BollingerBands } from 'technicalindicators';

export const calculateATR = (high: number[], low: number[], close: number[], period: number) => {
  return ATR.calculate({ high, low, close, period });
};

export const calculateBollingerBands = (prices: number[], period: number, stdDev: number) => {
  return BollingerBands.calculate({ period, stdDev, values: prices });
};
