import { EventEmitter } from "events";
import { PriceService } from "./priceService";

export class MarketService extends EventEmitter {
  private priceService: PriceService;

  constructor() {
    super();
    this.priceService = new PriceService();
    this.startSimulation();
  }

  private startSimulation() {
    const symbols = ['BTC', 'ETH', 'SOL', 'AAPL', 'MSFT'];
    const bases: Record<string, number> = {
      'BTC': 65000,
      'ETH': 3500,
      'SOL': 150,
      'AAPL': 175,
      'MSFT': 420
    };
    
    // Initialize prices
    symbols.forEach(symbol => {
      this.priceService.updatePrice({
        symbol,
        price: bases[symbol],
        change: 0,
        volume: 0,
        timestamp: new Date()
      });
    });

    setInterval(() => {
      symbols.forEach(async symbol => {
        const lastTick = await this.priceService.getLatestPrice(symbol);
        const base = lastTick ? lastTick.price : bases[symbol];
        const change = (Math.random() - 0.5) * (base * 0.02);
        const price = base + change;
        
        const tick = {
          symbol,
          price,
          change: (change / base) * 100, // percentage change
          volume: (lastTick ? lastTick.volume : 0) + Math.floor(Math.random() * 1000),
          timestamp: new Date()
        };
        this.priceService.updatePrice(tick);
        this.broadcastUpdate(tick);
      });
    }, 2000);
  }

  async getMarketData(symbol?: string) {
    if (symbol) {
      return this.priceService.getLatestPrice(symbol);
    }
    const symbols = ['BTC', 'ETH', 'SOL', 'AAPL', 'MSFT'];
    const data = await Promise.all(symbols.map(s => this.priceService.getLatestPrice(s)));
    return data.filter(d => d !== null);
  }

  async getGainers() {
    const data = await this.getMarketData();
    return (data as any[]).sort((a, b) => b.change - a.change).slice(0, 5);
  }

  async getLosers() {
    const data = await this.getMarketData();
    return (data as any[]).sort((a, b) => a.change - b.change).slice(0, 5);
  }

  async getTopMovers() {
    const data = await this.getMarketData();
    return (data as any[]).sort((a, b) => Math.abs(b.change) - Math.abs(a.change)).slice(0, 5);
  }

  async getMarketStatus() {
    return {
      status: 'open',
      lastUpdate: new Date(),
      activeSessions: ['NYSE', 'NASDAQ', 'CRYPTO']
    };
  }

  async broadcastUpdate(update: any) {
    this.emit("marketUpdate", update);
  }
}
