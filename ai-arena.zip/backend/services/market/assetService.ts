export class AssetService {
  private assets = [
    { symbol: 'BTC', name: 'Bitcoin', type: 'crypto' },
    { symbol: 'ETH', name: 'Ethereum', type: 'crypto' },
    { symbol: 'SOL', name: 'Solana', type: 'crypto' },
    { symbol: 'AAPL', name: 'Apple Inc.', type: 'stock' },
    { symbol: 'MSFT', name: 'Microsoft Corp.', type: 'stock' }
  ];

  async getAssets() {
    return this.assets;
  }

  async getAsset(symbol: string) {
    return this.assets.find(a => a.symbol === symbol) || null;
  }

  async getWatchlist(userId: string) {
    // For now returning default watchlist
    return this.assets.slice(0, 3);
  }
}
