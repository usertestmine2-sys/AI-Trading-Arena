import { PriceTick } from "../../types/market";
import { CacheManager } from "../../utils/cache";

export class PriceService {
  private cache = new CacheManager<PriceTick>();

  async getLatestPrice(symbol: string): Promise<PriceTick | null> {
    return this.cache.get(`price:${symbol}`);
  }

  async updatePrice(tick: PriceTick) {
    this.cache.set(`price:${tick.symbol}`, tick, 60); // 60s cache
  }
}
