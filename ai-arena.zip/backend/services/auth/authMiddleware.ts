import { Request, Response, NextFunction } from "express";
import { getSupabase } from "../supabaseClient";
import { AuthenticatedRequest, UserRole } from "../../types/auth";

export const authMiddleware = (allowedRoles?: UserRole[]) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ error: "Missing authorization header" });
    }

    const token = authHeader.split(" ")[1];
    const { data, error } = await getSupabase().auth.getUser(token);

    if (error || !data.user) {
      return res.status(401).json({ error: "Invalid token" });
    }

    const role = data.user.user_metadata.role as UserRole;

    if (allowedRoles && !allowedRoles.includes(role)) {
      return res.status(403).json({ error: "Forbidden" });
    }

    (req as AuthenticatedRequest).user = {
      id: data.user.id,
      email: data.user.email,
      role: role,
    };

    next();
  };
};
