import { getSupabase, getSupabaseAdmin } from "../supabaseClient";
import { UserRole } from "../../types/auth";

export class AuthService {
  private supabase = getSupabase();
  private supabaseAdmin = getSupabaseAdmin();

  async signUp(email: string, password: string, role: UserRole) {
    const { data, error } = await this.supabase.auth.signUp({
      email,
      password,
      options: {
        data: { role },
      },
    });
    if (error) throw error;
    return data;
  }

  async login(email: string, password: string) {
    const { data, error } = await this.supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
    return data;
  }

  async logout() {
    const { error } = await this.supabase.auth.signOut();
    if (error) throw error;
  }

  async getUser(userId: string) {
    const { data, error } = await this.supabaseAdmin.auth.admin.getUserById(userId);
    if (error) throw error;
    return data;
  }
}
