import { UserRole } from "../../types/auth";

export class PermissionManager {
  static canAccess(userRole: UserRole, requiredRole: UserRole): boolean {
    const roleHierarchy = {
      [UserRole.ADMIN]: 3,
      [UserRole.AI]: 2,
      [UserRole.USER]: 1,
    };
    return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
  }
}
