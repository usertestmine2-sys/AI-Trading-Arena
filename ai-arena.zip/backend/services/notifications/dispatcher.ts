import { Notification, NotificationChannel } from "../../types/notifications";
import { NotificationQueue } from "./queue";
import { INotificationAdapter, EmailAdapter, TelegramAdapter, DiscordAdapter, PushAdapter } from "./adapters";

export class NotificationDispatcher {
  private queue: NotificationQueue;
  private adapters: Record<NotificationChannel, INotificationAdapter>;

  constructor() {
    this.queue = new NotificationQueue();
    this.adapters = {
      email: new EmailAdapter(),
      telegram: new TelegramAdapter(),
      discord: new DiscordAdapter(),
      push: new PushAdapter(),
    };

    this.queue.on('notification', async (notification: Notification) => {
      await this.dispatch(notification);
    });
  }

  private async dispatch(notification: Notification) {
    for (const channel of notification.channels) {
      const adapter = this.adapters[channel];
      if (adapter) {
        await adapter.send(notification).catch(console.error);
      }
    }
  }

  enqueue(notification: Notification) {
    this.queue.enqueue(notification);
  }
}
