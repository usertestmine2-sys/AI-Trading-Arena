import { Notification } from "../../types/notifications";
import { EventEmitter } from "events";

export class NotificationQueue extends EventEmitter {
  private queue: Notification[] = [];

  enqueue(notification: Notification) {
    this.queue.push(notification);
    this.emit('notification', notification);
  }

  dequeue(): Notification | undefined {
    return this.queue.shift();
  }
}
