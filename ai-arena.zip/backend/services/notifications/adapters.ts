import { Notification } from "../../types/notifications";

export interface INotificationAdapter {
  send(notification: Notification): Promise<void>;
}

export class EmailAdapter implements INotificationAdapter {
  async send(notification: Notification): Promise<void> {
    console.log(`[Email] Sending: ${notification.title}`);
  }
}

export class TelegramAdapter implements INotificationAdapter {
  async send(notification: Notification): Promise<void> {
    console.log(`[Telegram] Sending: ${notification.title}`);
  }
}

export class DiscordAdapter implements INotificationAdapter {
  async send(notification: Notification): Promise<void> {
    console.log(`[Discord] Sending: ${notification.title}`);
  }
}

export class PushAdapter implements INotificationAdapter {
  async send(notification: Notification): Promise<void> {
    console.log(`[Push] Sending: ${notification.title}`);
  }
}
