import { BaseRepository } from "./baseRepository";

export class BaseService<T> {
  protected repository: BaseRepository<T>;

  constructor(repository: BaseRepository<T>) {
    this.repository = repository;
  }

  async getAll(pagination?: any, filters?: any, sort?: any) {
    return this.repository.findAll(pagination, filters, sort);
  }

  async getById(id: string) {
    return this.repository.findById(id);
  }

  async create(data: Partial<T>) {
    return this.repository.create(data);
  }

  async update(id: string, data: Partial<T>) {
    return this.repository.update(id, data);
  }

  async delete(id: string) {
    return this.repository.softDelete(id);
  }
}
