import cron from 'node-cron';
import { ScheduledTask } from '../../types/scheduler';
import { Tasks } from './tasks';

export class SchedulerEngine {
  private tasks: ScheduledTask[] = [
    { name: 'marketOpen', expression: '0 9 * * 1-5', task: Tasks.marketOpen },
    { name: 'marketClose', expression: '0 16 * * 1-5', task: Tasks.marketClose },
    { name: 'dailyReport', expression: '0 17 * * 1-5', task: Tasks.dailyReport },
    { name: 'healthCheck', expression: '*/5 * * * *', task: Tasks.healthCheck },
    { name: 'cleanup', expression: '0 0 * * *', task: Tasks.cleanup },
    { name: 'aiRefresh', expression: '0 3 * * *', task: Tasks.aiRefresh },
    { name: 'strategyRefresh', expression: '*/30 * * * *', task: Tasks.strategyRefresh },
    { name: 'queueWorker', expression: '* * * * *', task: Tasks.queueWorker }
  ];

  constructor() {
    this.init();
  }

  private init() {
    this.tasks.forEach(t => {
      cron.schedule(t.expression, async () => {
        try {
          console.log(`[Scheduler] Starting task: ${t.name}`);
          await t.task();
          console.log(`[Scheduler] Completed task: ${t.name}`);
        } catch (error) {
          console.error(`[Scheduler] Error in task ${t.name}:`, error);
        }
      });
    });
    console.log("[Scheduler] All jobs initialized");
  }
}
