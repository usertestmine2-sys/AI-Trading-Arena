import { Server, Socket } from 'socket.io';
import { Server as HttpServer } from 'http';

export class WebSocketEngine {
  private io: Server;

  constructor(server: HttpServer) {
    this.io = new Server(server, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    this.setupEvents();
  }

  private setupEvents() {
    this.io.on('connection', (socket: Socket) => {
      console.log('Client connected:', socket.id);

      socket.on('heartbeat', (data) => {
        socket.emit('heartbeat', { timestamp: new Date() });
      });

      socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
      });
    });
  }

  broadcast(event: string, data: any) {
    this.io.emit(event, data);
  }
}
