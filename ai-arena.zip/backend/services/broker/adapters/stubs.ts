import { IBroker } from "../../../types/broker";
import { Order, Trade, Position } from "../../../types/trading";

abstract class BaseStubBroker implements IBroker {
  async placeOrder(order: Order): Promise<Trade> {
    throw new Error("Method not implemented (Live trading disabled)");
  }
  async cancelOrder(orderId: string): Promise<boolean> {
    throw new Error("Method not implemented (Live trading disabled)");
  }
  async getPositions(): Promise<Position[]> {
    throw new Error("Method not implemented (Live trading disabled)");
  }
  async getBalance(): Promise<number> {
    throw new Error("Method not implemented (Live trading disabled)");
  }
}

export class AngelAdapter extends BaseStubBroker {}
export class BinanceAdapter extends BaseStubBroker {}
export class PolygonAdapter extends BaseStubBroker {}
