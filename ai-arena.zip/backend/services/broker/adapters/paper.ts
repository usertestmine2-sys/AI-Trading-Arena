import { IBroker } from "../../../types/broker";
import { Order, Trade, Position } from "../../../types/trading";
import { randomUUID } from "crypto";
import { PriceService } from "../../market/priceService";

export class PaperBrokerAdapter implements IBroker {
  private priceService = new PriceService();

  async placeOrder(order: Order): Promise<Trade> {
    console.log(`[PaperBroker] Placing order: ${order.id}`);
    const latestPrice = await this.priceService.getLatestPrice(order.symbol);
    const price = order.price || (latestPrice ? latestPrice.price : 100);
    return {
      id: randomUUID(),
      orderId: order.id,
      symbol: order.symbol,
      price: price,
      quantity: order.quantity,
      timestamp: new Date(),
    };
  }

  async cancelOrder(orderId: string): Promise<boolean> {
    console.log(`[PaperBroker] Cancelling order: ${orderId}`);
    return true;
  }

  async getPositions(): Promise<Position[]> {
    return [];
  }

  async getBalance(): Promise<number> {
    return 100000;
  }
}

