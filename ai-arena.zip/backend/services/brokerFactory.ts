import { IBroker } from "../types/broker";
import { PaperBrokerAdapter } from "./broker/adapters/paper";
import { AngelAdapter, BinanceAdapter, PolygonAdapter } from "./broker/adapters/stubs";

export class BrokerFactory {
  static getBroker(type: 'paper' | 'angel' | 'binance' | 'polygon'): IBroker {
    switch (type) {
      case 'paper':
        return new PaperBrokerAdapter();
      case 'angel':
        return new AngelAdapter();
      case 'binance':
        return new BinanceAdapter();
      case 'polygon':
        return new PolygonAdapter();
      default:
        throw new Error("Invalid broker type");
    }
  }
}
