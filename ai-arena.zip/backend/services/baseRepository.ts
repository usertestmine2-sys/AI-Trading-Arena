import { SupabaseClient } from "@supabase/supabase-js";
import { getSupabase } from "./supabaseClient";
import { PaginationParams, FilterParams, SortParams } from "../types/db";

export class BaseRepository<T> {
  protected client: SupabaseClient;
  protected table: string;

  constructor(table: string) {
    this.client = getSupabase();
    this.table = table;
  }

  async findAll(
    pagination?: PaginationParams,
    filters?: FilterParams,
    sort?: SortParams
  ) {
    let query = this.client.from(this.table).select("*");

    if (filters) {
      for (const [key, value] of Object.entries(filters)) {
        query = query.eq(key, value);
      }
    }

    if (sort) {
      query = query.order(sort.column, { ascending: sort.order === 'asc' });
    }

    if (pagination) {
      const from = (pagination.page - 1) * pagination.pageSize;
      query = query.range(from, from + pagination.pageSize - 1);
    }

    return query;
  }

  async findById(id: string) {
    return this.client.from(this.table).select("*").eq("id", id).single();
  }

  async create(data: Partial<T>) {
    return this.client.from(this.table).insert(data as any).select().single();
  }

  async update(id: string, data: Partial<T>) {
    return this.client.from(this.table).update(data as any).eq("id", id).select().single();
  }

  async softDelete(id: string) {
    return this.client.from(this.table).update({ deletedAt: new Date().toISOString() } as any).eq("id", id);
  }

  async bulkInsert(data: Partial<T>[]) {
    return this.client.from(this.table).insert(data as any);
  }

  async bulkUpdate(ids: string[], data: Partial<T>) {
    return this.client.from(this.table).update(data as any).in("id", ids);
  }
}
