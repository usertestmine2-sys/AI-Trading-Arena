import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import http from "http";
import helmet from "helmet";
import cors from "cors";
import compression from "compression";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import { errorHandler, notFoundHandler } from "./middleware/errorMiddleware";
import { router, marketService } from "./routes";
import { WebSocketEngine } from "./services/websocket/engine";
import { SchedulerEngine } from "./services/scheduler/engine";
import { logger } from "./utils/logger";
import { config } from "./config/config";

async function startServer() {
  const app = express();
  const PORT = config.port;
  const httpServer = http.createServer(app);

  // Initialize WebSocket Engine
  const wsEngine = new WebSocketEngine(httpServer);
  
  // Initialize Scheduler
  const scheduler = new SchedulerEngine();

  app.use(helmet());
  app.use(cors());
  app.use(compression());
  app.use(morgan("combined", {
    stream: { write: (message: string) => logger.info(message.trim()) }
  }));
  app.use(express.json());

  app.set("trust proxy", 1);

  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    validate: false,
  });
  app.use(limiter);

  // API routes
  app.use("/api", router);

  marketService.on("marketUpdate", (update) => {
    wsEngine.broadcast("marketUpdate", update);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.use(notFoundHandler);
  app.use(errorHandler);

  const server = httpServer.listen(PORT, "0.0.0.0", () => {
    logger.info(`Server running on http://localhost:${PORT}`);
  });

  const shutdown = (signal: string) => {
    logger.info(`${signal} received. Shutting down gracefully...`);
    server.close(() => {
      logger.info("Server closed");
      process.exit(0);
    });
  };

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

startServer();
