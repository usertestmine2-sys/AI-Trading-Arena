import { Router } from "express";
import swaggerUi from "swagger-ui-express";
import { specs } from "../docs/swagger";
import { checkSupabaseConnection } from "../services/supabaseClient";
import { DashboardService } from "../services/analytics/dashboardService";
import { PortfolioService } from "../services/trading/portfolioService";
import { StrategyRegistry } from "../services/strategy/registry";
import { OrderService } from "../services/trading/orderService";
import { MarketService } from "../services/market/marketService";
import { AssetService } from "../services/market/assetService";
import { SectorService } from "../services/market/sectorService";
import { Scanner } from "../services/market/scanner";
import { TradeService } from "../services/trading/tradeService";
import { EquityService } from "../services/analytics/equityService";
import { CompetitorService } from "../services/strategy/competitorService";

export const router = Router();

// Shared service instances
const portfolioService = new PortfolioService();
const strategyRegistry = new StrategyRegistry();
const orderService = new OrderService();
const dashboardService = new DashboardService();
export const marketService = new MarketService();
const assetService = new AssetService();
const sectorService = new SectorService();
const scanner = new Scanner(marketService);
const tradeService = new TradeService();
const equityService = new EquityService();
const competitorService = new CompetitorService();

router.use("/api-docs", swaggerUi.serve, swaggerUi.setup(specs));

/**
 * @openapi
 * /health:
 *   get:
 *     summary: Health check
 *     responses:
 *       200:
 *         description: System is healthy
 */
router.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

/**
 * @openapi
 * /supabase-check:
 *   get:
 *     summary: Check Supabase connection
 *     responses:
 *       200:
 *         description: Connection status
 */
router.get("/supabase-check", async (req, res) => {
  const isConnected = await checkSupabaseConnection();
  res.json({ connected: isConnected });
});

/**
 * @openapi
 * /portfolio:
 *   get:
 *     summary: Get portfolio data
 */
router.get("/portfolio", (req, res) => {
  // Real service integration
  const portfolio = portfolioService.getPortfolio();
  res.json({
    balance: portfolio.balance,
    dailyPnL: 0,
    totalPositions: portfolio.positions.length
  });
});

/**
 * @openapi
 * /positions:
 *   get:
 *     summary: Get portfolio positions
 */
router.get("/positions", (req, res) => {
  // Real service integration
  const portfolio = portfolioService.getPortfolio();
  res.json(portfolio.positions);
});

router.get("/competitors", async (req, res) => {
  // Real service integration
  const competitors = await competitorService.getCompetitors();
  res.json(competitors);
});

router.get("/market", async (req, res) => {
  // Real service integration
  const data = await marketService.getMarketData();
  res.json(data);
});

router.get("/market/status", async (req, res) => {
  const status = await marketService.getMarketStatus();
  res.json(status);
});

router.get("/market/gainers", async (req, res) => {
  const gainers = await marketService.getGainers();
  res.json(gainers);
});

router.get("/market/losers", async (req, res) => {
  const losers = await marketService.getLosers();
  res.json(losers);
});

router.get("/market/topMovers", async (req, res) => {
  const movers = await marketService.getTopMovers();
  res.json(movers);
});

router.post("/market/scan", async (req, res) => {
  const results = await scanner.scanSymbols(req.body);
  res.json(results);
});

router.get("/assets", async (req, res) => {
  const assets = await assetService.getAssets();
  res.json(assets);
});

router.get("/watchlist", async (req, res) => {
  const watchlist = await assetService.getWatchlist("user1");
  res.json(watchlist);
});

router.get("/sectors", async (req, res) => {
  // Real service integration
  const data = await sectorService.getSectors();
  res.json(data);
});

router.get("/strategies", (req, res) => {
  // Real service integration
  res.json(strategyRegistry.getAllStrategies());
});

router.post("/orders", async (req, res) => {
  // Real service integration
  const order = await orderService.createOrder(req.body);
  res.json(order);
});

router.get("/analytics/equity", async (req, res) => {
  // Real service integration
  const equity = await equityService.getEquityCurve();
  res.json(equity);
});

router.get("/analytics/metrics", async (req, res) => {
  const data = await dashboardService.getDashboardData();
  res.json(data.aiPerformance);
});

router.get("/trades", async (req, res) => {
  // Real service integration
  const trades = await tradeService.getTrades();
  res.json(trades);
});

/**
 * @openapi
 * /analytics/dashboard:
 *   get:
 *     summary: Get dashboard analytics
 *     responses:
 *       200:
 *         description: Dashboard data
 */
router.get("/analytics/dashboard", async (req, res) => {
  const data = await dashboardService.getDashboardData();
  res.json(data);
});
