export enum RiskLevel {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}

export enum MarketType {
  CRYPTO = 'crypto',
  FOREX = 'forex',
  EQUITY = 'equity'
}

export enum StrategyStatus {
  ENABLED = 'enabled',
  DISABLED = 'disabled',
  MAINTENANCE = 'maintenance'
}

export interface Strategy {
  id: string;
  name: string;
  description: string;
  riskLevel: RiskLevel;
  timeframe: string;
  marketType: MarketType;
  entryConditions: string[];
  exitConditions: string[];
  requiredIndicators: string[];
  aiCompatibility: boolean;
  paperTradingSupport: boolean;
  version: string;
  status: StrategyStatus;
  priority: number;
  dependencies: string[];
  executionInterface: string;
  performanceMetadata: {
    winRate: number;
    profitFactor: number;
  };
  healthStatus: 'healthy' | 'warning' | 'critical';
}
