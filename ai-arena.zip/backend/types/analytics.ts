export interface AnalyticsMetrics {
  winRate: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  totalTrades: number;
  totalProfit: number;
}

export interface HeatmapData {
  data: { date: string; value: number }[];
}

export interface DashboardData {
  aiPerformance: AnalyticsMetrics;
  strategyPerformance: AnalyticsMetrics;
  tradeAnalytics: any;
  portfolioAnalytics: any;
}
