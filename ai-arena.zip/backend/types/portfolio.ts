import { Position } from "./trading";

export interface PortfolioSnapshot {
  timestamp: Date;
  balance: number;
  holdings: Position[];
  totalValue: number;
}

export interface PortfolioPerformance {
  returns: number;
  volatility: number;
  sharpeRatio: number;
  drawdown: number;
}

export interface PortfolioAllocation {
  symbol: string;
  weight: number;
}
