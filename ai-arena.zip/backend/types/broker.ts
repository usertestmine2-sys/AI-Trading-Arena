import { Order, Trade, Position } from "./trading";

export interface IBroker {
  placeOrder(order: Order): Promise<Trade>;
  cancelOrder(orderId: string): Promise<boolean>;
  getPositions(): Promise<Position[]>;
  getBalance(): Promise<number>;
}
