export type CronExpression = string;

export interface ScheduledTask {
  name: string;
  expression: CronExpression;
  task: () => Promise<void>;
}
