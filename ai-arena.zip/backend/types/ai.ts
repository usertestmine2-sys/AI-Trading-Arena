import { Type } from "@google/genai";

export enum AIProvider {
  GOOGLE = "google",
  OPENROUTER = "openrouter",
}

export interface AIModel {
  id: string;
  name: string;
  provider: AIProvider;
  isPaid: boolean;
  description: string;
}

export interface AIUsage {
  modelId: string;
  promptTokens: number;
  completionTokens: number;
  cost: number;
  timestamp: Date;
}

export interface EngineConfig {
  defaultModelId: string;
  fallbackModelId: string;
}
