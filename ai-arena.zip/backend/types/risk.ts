export interface RiskLimits {
  maxDailyLoss: number;
  maxDrawdown: number;
  maxPositionSize: number;
  maxExposure: number;
}

export interface PositionSizingConfig {
  riskPerTrade: number; // percentage of capital
  stopLossDistance: number; // in percentage
}
