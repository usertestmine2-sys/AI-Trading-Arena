export enum UserRole {
  ADMIN = 'admin',
  AI = 'ai',
  USER = 'user',
}

import { Request } from "express";

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    role: UserRole;
    email?: string;
  };
}
