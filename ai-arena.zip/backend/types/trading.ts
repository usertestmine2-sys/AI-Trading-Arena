export type OrderSide = 'buy' | 'sell';
export type OrderType = 'market' | 'limit';
export type OrderStatus = 'pending' | 'filled' | 'cancelled' | 'rejected';

export interface Order {
  id: string;
  symbol: string;
  side: OrderSide;
  type: OrderType;
  quantity: number;
  price?: number;
  status: OrderStatus;
  timestamp: Date;
}

export interface Position {
  symbol: string;
  quantity: number;
  averagePrice: number;
}

export interface Trade {
  id: string;
  orderId: string;
  symbol: string;
  price: number;
  quantity: number;
  timestamp: Date;
}

export interface Portfolio {
  balance: number;
  positions: Position[];
}
