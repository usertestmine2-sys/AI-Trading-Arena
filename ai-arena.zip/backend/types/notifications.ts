export type NotificationChannel = 'email' | 'telegram' | 'discord' | 'push';
export type NotificationType = 'system' | 'trade' | 'risk' | 'ai';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  channels: NotificationChannel[];
  timestamp: Date;
}
