export interface OHLC {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp: Date;
}

export interface PriceTick {
  symbol: string;
  price: number;
  change: number;
  volume: number;
  timestamp: Date;
}

export interface MarketStatus {
  symbol: string;
  status: 'open' | 'closed' | 'halted';
  lastUpdate: Date;
}
