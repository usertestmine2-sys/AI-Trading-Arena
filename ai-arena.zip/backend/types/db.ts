export interface PaginationParams {
  page: number;
  pageSize: number;
}

export interface FilterParams {
  [key: string]: any;
}

export interface SortParams {
  column: string;
  order: 'asc' | 'desc';
}

export interface AuditFields {
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date | null;
}

export interface BaseEntity extends AuditFields {
  id: string;
}
