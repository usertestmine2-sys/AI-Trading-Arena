import { Response, NextFunction } from "express";
import { AuthenticatedRequest, UserRole } from "../types/auth";
import { getSupabase } from "../services/supabaseClient";

export const authenticate = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ success: false, message: "No token provided" });
  }

  const token = authHeader.split(" ")[1];
  const { data, error } = await getSupabase().auth.getUser(token);

  if (error || !data.user) {
    return res.status(401).json({ success: false, message: "Invalid token" });
  }

  // Assuming role is stored in user_metadata or app_metadata in Supabase
  const role = (data.user.app_metadata?.role as UserRole) || UserRole.USER;

  req.user = {
    id: data.user.id,
    role,
    email: data.user.email,
  };

  next();
};

export const authorize = (roles: UserRole[]) => {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }
    next();
  };
};
