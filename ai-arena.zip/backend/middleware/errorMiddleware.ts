import { Request, Response, NextFunction } from "express";
import { logger } from "../utils/logger";

export const notFoundHandler = (req: Request, res: Response, next: NextFunction) => {
  logger.warn(`Resource not found: ${req.originalUrl}`);
  res.status(404).json({ success: false, message: "Resource not found" });
};

export const errorHandler = (err: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error(`Internal server error: ${err.message}`, err);
  res.status(500).json({ success: false, message: "Internal Server Error" });
};
