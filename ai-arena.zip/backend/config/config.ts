import dotenv from "dotenv";

dotenv.config();

const requiredEnvVars = [
  "GEMINI_API_KEY",
  "OPENROUTER_API_KEY",
  "SUPABASE_URL",
  "SUPABASE_ANON_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
];

const missingVars = requiredEnvVars.filter((varName) => !process.env[varName]);

if (missingVars.length > 0) {
  console.warn(`Warning: Missing environment variables: ${missingVars.join(", ")}. Using fallback defaults to allow preview startup.`);
}

export const config = {
  geminiApiKey: process.env.GEMINI_API_KEY || "placeholder_gemini_key",
  openRouterApiKey: process.env.OPENROUTER_API_KEY || "placeholder_openrouter_key",
  supabaseUrl: process.env.SUPABASE_URL || "https://placeholder.supabase.co",
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || "placeholder_anon_key",
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY || "placeholder_service_role_key",
  deepseekApiKey: process.env.DEEPSEEK_API_KEY,
  githubToken: process.env.GITHUB_TOKEN,
  port: parseInt(process.env.PORT || "3000", 10),
  nodeEnv: process.env.NODE_ENV || "development",
};
