import {create} from 'zustand';

interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'error';
}

interface ArenaState {
  activeCompetitors: string[];
  notifications: Notification[];
  setCompetitors: (ids: string[]) => void;
  addNotification: (notification: Omit<Notification, 'id'>) => void;
  removeNotification: (id: string) => void;
}

export const useArenaStore = create<ArenaState>((set) => ({
  activeCompetitors: [],
  notifications: [],
  setCompetitors: (ids) => set({ activeCompetitors: ids }),
  addNotification: (n) => set((state) => ({ 
    notifications: [...state.notifications, { ...n, id: Math.random().toString(36).substring(7) }] 
  })),
  removeNotification: (id) => set((state) => ({ 
    notifications: state.notifications.filter((n) => n.id !== id) 
  })),
}));
