import { MarketData, SectorData, Strategy, Position, Order, EquityCurveData, AnalyticsMetrics } from '../types';

export interface PortfolioData {
  balance: number;
  dailyPnL: number;
  totalPositions: number;
}

export const fetchPortfolioData = async (): Promise<PortfolioData> => {
  const response = await fetch('/api/portfolio');
  if (!response.ok) throw new Error('Failed to fetch portfolio');
  return response.json();
};

export const fetchMarketData = async (): Promise<MarketData[]> => {
  const response = await fetch('/api/market');
  if (!response.ok) throw new Error('Failed to fetch market data');
  return response.json();
};

export const fetchSectors = async (): Promise<SectorData[]> => {
  const response = await fetch('/api/sectors');
  if (!response.ok) throw new Error('Failed to fetch sectors');
  return response.json();
};

export const fetchStrategies = async (): Promise<Strategy[]> => {
  const response = await fetch('/api/strategies');
  if (!response.ok) throw new Error('Failed to fetch strategies');
  return response.json();
};

export const fetchPositions = async (): Promise<Position[]> => {
  const response = await fetch('/api/positions');
  if (!response.ok) throw new Error('Failed to fetch positions');
  return response.json();
};

export const placeOrder = async (order: Omit<Order, 'id' | 'status'>): Promise<Order> => {
  const response = await fetch('/api/orders', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(order)
  });
  if (!response.ok) throw new Error('Failed to place order');
  return response.json();
};

export const fetchEquityCurve = async (): Promise<EquityCurveData[]> => {
  const response = await fetch('/api/analytics/equity');
  if (!response.ok) throw new Error('Failed to fetch equity curve');
  return response.json();
};

export const fetchAnalyticsMetrics = async (): Promise<AnalyticsMetrics> => {
  const response = await fetch('/api/analytics/metrics');
  if (!response.ok) throw new Error('Failed to fetch analytics metrics');
  return response.json();
};
