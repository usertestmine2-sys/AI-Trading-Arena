import LivePriceTable from '../components/market/LivePriceTable';
import SectorPerformance from '../components/market/SectorPerformance';

export default function MarketTerminal() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      <div className="lg:col-span-3">
        <LivePriceTable />
      </div>
      <div className="lg:col-span-1">
        <SectorPerformance />
      </div>
    </div>
  );
}
