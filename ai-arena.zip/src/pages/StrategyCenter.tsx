import {useQuery} from '@tanstack/react-query';
import {fetchStrategies} from '@/src/api/arenaApi';
import StrategyCard from '../components/strategy/StrategyCard';
import {useState} from 'react';
import {cn} from '@/src/lib/utils';

export default function StrategyCenter() {
  const {data} = useQuery({queryKey: ['strategies'], queryFn: fetchStrategies});
  const [filter, setFilter] = useState('all');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold uppercase tracking-widest">Strategy Center</h2>
        <div className="flex gap-2">
          {['all', 'active', 'inactive'].map(f => (
            <button 
              key={f}
              onClick={() => setFilter(f)}
              className={cn("px-4 py-2 text-xs font-bold uppercase tracking-widest rounded transition-colors", 
                filter === f ? "bg-accent-purple text-white" : "bg-bg-panel hover:bg-white/5"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {data?.filter(s => filter === 'all' || (filter === 'active' && s.isActive) || (filter === 'inactive' && !s.isActive)).map(s => (
          <StrategyCard key={s.id} strategy={s} />
        ))}
      </div>
    </div>
  );
}
