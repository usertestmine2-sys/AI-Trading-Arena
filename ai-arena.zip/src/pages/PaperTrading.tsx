import OrderEntry from '../components/trading/OrderEntry';
import PositionsTable from '../components/trading/PositionsTable';

export default function PaperTrading() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      <div className="lg:col-span-1">
        <OrderEntry />
      </div>
      <div className="lg:col-span-3">
        <PositionsTable />
      </div>
    </div>
  );
}
