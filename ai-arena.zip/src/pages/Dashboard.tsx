import PortfolioSummary from '@/src/components/dashboard/PortfolioSummary';
import AISystemStatus from '@/src/components/dashboard/AISystemStatus';
import AILeaderboard from '@/src/components/dashboard/AILeaderboard';

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="space-y-6 lg:col-span-1">
        <PortfolioSummary />
        <AISystemStatus competitors={[]} />
      </div>
      <div className="lg:col-span-2">
        <AILeaderboard />
      </div>
      <div className="bg-bg-panel border border-border-glow p-6 rounded-xl lg:col-span-3">
        <h2 className="text-sm text-text-secondary uppercase mb-4">Market Heatmap</h2>
        <div className="h-64 flex items-center justify-center border-2 border-dashed border-border-glow text-text-secondary">
          Market Heatmap Visualization
        </div>
      </div>
    </div>
  );
}
