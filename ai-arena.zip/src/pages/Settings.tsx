import {Settings, User, Brain, Shield, Bell, Palette, Key, Database, Terminal} from 'lucide-react';
import {motion} from 'motion/react';

const sections = [
  {title: 'User Profile', icon: User},
  {title: 'Broker Settings', icon: Terminal},
  {title: 'AI Settings', icon: Brain},
  {title: 'Risk Settings', icon: Shield},
  {title: 'Notification Settings', icon: Bell},
  {title: 'Theme Settings', icon: Palette},
  {title: 'API Keys', icon: Key},
  {title: 'Database Status', icon: Database},
];

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold uppercase tracking-widest">Enterprise Settings</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sections.map(s => (
          <motion.div 
            key={s.title}
            whileHover={{y: -4}}
            className="bg-bg-panel border border-border-glow p-6 rounded-xl flex items-start gap-4 hover:border-accent-purple transition-colors"
          >
            <div className="p-3 bg-bg-dark rounded-lg border border-border-glow">
              <s.icon className="w-6 h-6 text-accent-purple" />
            </div>
            <div>
              <h3 className="font-bold">{s.title}</h3>
              <p className="text-xs text-text-secondary mt-1">Configure {s.title.toLowerCase()} preferences.</p>
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="bg-bg-panel border border-border-glow p-6 rounded-xl">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <Terminal className="w-5 h-5 text-accent-purple" />
          System Logs
        </h3>
        <div className="h-64 bg-bg-dark rounded-lg p-4 font-mono text-xs text-text-secondary overflow-auto">
          [07:46:30] System initialized...<br/>
          [07:46:31] Connection established to Broker API...<br/>
          [07:46:32] AI Engine online...<br/>
          [07:46:33] Risk monitor active...
        </div>
      </div>
    </div>
  );
}
