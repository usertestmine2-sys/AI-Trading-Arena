import PerformanceChart from '../components/analytics/PerformanceChart';
import MetricsCards from '../components/analytics/MetricsCards';

export default function AnalyticsCenter() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold uppercase tracking-widest">Analytics Center</h2>
      <MetricsCards />
      <PerformanceChart />
    </div>
  );
}
