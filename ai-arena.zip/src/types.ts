export interface Competitor {
  id: string;
  name: string;
  model: string;
  rank: number;
  status: 'active' | 'idle' | 'thinking';
  winRate: number;
  accuracy: number;
  riskScore: number;
  confidence: number;
  currentStrategy: string;
  currentTrade: string;
}

export interface MarketData {
  symbol: string;
  price: number;
  change: number;
  volume: number;
}

export interface SectorData {
  name: string;
  performance: number;
}

export interface Strategy {
  id: string;
  name: string;
  description: string;
  winRate: number;
  riskScore: number;
  performance: number;
  isActive: boolean;
}

export interface Position {
  symbol: string;
  shares: number;
  avgPrice: number;
  currentPrice: number;
  unrealizedPnL: number;
}

export interface Order {
  id: string;
  symbol: string;
  side: 'buy' | 'sell';
  shares: number;
  price: number;
  status: 'filled' | 'pending';
}

export interface EquityCurveData {
  date: string;
  value: number;
}

export interface AnalyticsMetrics {
  winRate: number;
  lossRate: number;
  sharpeRatio: number;
  sortinoRatio: number;
  drawdown: number;
}
