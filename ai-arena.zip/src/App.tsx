/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import {QueryClient, QueryClientProvider} from '@tanstack/react-query';
import ArenaLayout from './components/layout/ArenaLayout';
import ErrorBoundary from './components/system/ErrorBoundary';
import Dashboard from './pages/Dashboard';
import StrategyCenter from './pages/StrategyCenter';
import MarketTerminal from './pages/MarketTerminal';
import PaperTrading from './pages/PaperTrading';
import AnalyticsCenter from './pages/AnalyticsCenter';
import SettingsPage from './pages/Settings';

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ErrorBoundary>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<ArenaLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="market" element={<MarketTerminal />} />
              <Route path="strategies" element={<StrategyCenter />} />
              <Route path="paper-trading" element={<PaperTrading />} />
              <Route path="analytics" element={<AnalyticsCenter />} />
              <Route path="settings" element={<SettingsPage />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </ErrorBoundary>
    </QueryClientProvider>
  );
}
