import {useQuery} from '@tanstack/react-query';
import {motion} from 'motion/react';
import {Competitor} from '@/src/types';
import {BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer} from 'recharts';

const fetchCompetitors = async (): Promise<Competitor[]> => {
  const response = await fetch('/api/competitors');
  if (!response.ok) throw new Error('Failed to fetch competitors');
  return response.json();
};

export default function AILeaderboard() {
  const {data, isLoading} = useQuery({
    queryKey: ['competitors'],
    queryFn: fetchCompetitors,
  });

  if (isLoading) return <div className="p-4 text-text-secondary">Loading leaderboard...</div>;

  return (
    <div className="bg-bg-panel border border-border-glow rounded-xl p-6">
      <h2 className="text-lg font-bold text-text-primary uppercase tracking-widest mb-6">AI Leaderboard</h2>
      <div className="space-y-4">
        {data?.map((c) => (
          <motion.div
            key={c.id}
            initial={{opacity: 0, y: 10}}
            animate={{opacity: 1, y: 0}}
            className="grid grid-cols-8 gap-4 items-center p-4 bg-bg-dark border border-border-glow rounded-lg hover:bg-bg-panel transition-colors"
          >
            <div className="font-bold text-lg text-accent-purple">#{c.rank}</div>
            <div className="col-span-2">
              <div className="font-bold">{c.name}</div>
              <div className="text-xs text-text-secondary">{c.model}</div>
            </div>
            <div>
              <div className="text-xs text-text-secondary">Win Rate</div>
              <div className="font-mono">{c.winRate}%</div>
            </div>
            <div>
              <div className="text-xs text-text-secondary">Accuracy</div>
              <div className="font-mono">{c.accuracy}%</div>
            </div>
            <div className="col-span-2">
              <div className="text-xs text-text-secondary">Current Strategy</div>
              <div className="font-mono truncate">{c.currentStrategy}</div>
            </div>
            <div className={c.status === 'thinking' ? "text-accent-purple animate-pulse" : "text-status-green"}>
              {c.status}
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-8 h-64">
         <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip contentStyle={{backgroundColor: '#0a0a0f', border: '1px solid #1f1f2e'}} />
                <Bar dataKey="winRate" fill="#8b5cf6" />
            </BarChart>
         </ResponsiveContainer>
      </div>
    </div>
  );
}
