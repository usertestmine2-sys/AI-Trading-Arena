import {useQuery} from '@tanstack/react-query';
import {fetchPortfolioData} from '@/src/api/arenaApi';
import {motion} from 'motion/react';

export default function PortfolioSummary() {
  const {data, isLoading} = useQuery({
    queryKey: ['portfolio'],
    queryFn: fetchPortfolioData,
  });

  if (isLoading) return <div className="p-4">Loading...</div>;

  return (
    <motion.div className="bg-bg-panel border border-border-glow p-6 rounded-xl">
      <h2 className="text-sm text-text-secondary uppercase mb-2">Account Balance</h2>
      <div className="text-3xl font-bold text-text-primary mb-4">${data?.balance.toLocaleString()}</div>
      <div className="flex gap-4">
        <div>
          <span className="text-xs text-text-secondary">Daily P&L</span>
          <div className={data?.dailyPnL! >= 0 ? "text-status-green" : "text-red-500"}>
            ${data?.dailyPnL.toLocaleString()}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
