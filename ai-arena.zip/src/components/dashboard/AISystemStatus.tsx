import {motion} from 'motion/react';
import {Competitor} from '@/src/types';

interface Props {
  competitors: Competitor[];
}

export default function AISystemStatus({competitors}: Props) {
  return (
    <div className="bg-bg-panel border border-border-glow p-6 rounded-xl">
      <h2 className="text-sm text-text-secondary uppercase mb-4">AI System Status</h2>
      <div className="space-y-4">
        {competitors.map(c => (
          <div key={c.id} className="flex justify-between items-center border-b border-border-glow pb-2">
            <div>
              <div className="font-bold">{c.name}</div>
              <div className="text-xs text-text-secondary">{c.model}</div>
            </div>
            <div className={c.status === 'thinking' ? "text-accent-purple animate-pulse" : "text-status-green"}>
              {c.status}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
