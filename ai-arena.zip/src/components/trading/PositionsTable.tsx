import {useQuery} from '@tanstack/react-query';
import {fetchPositions} from '@/src/api/arenaApi';

export default function PositionsTable() {
  const {data} = useQuery({queryKey: ['positions'], queryFn: fetchPositions});

  return (
    <div className="bg-bg-panel border border-border-glow rounded-xl p-5">
      <h3 className="font-bold uppercase text-sm mb-4">Open Positions</h3>
      <table className="w-full text-xs font-mono">
        <thead>
          <tr className="text-text-secondary border-b border-border-glow">
            <th className="text-left pb-2">SYMBOL</th>
            <th className="text-right pb-2">SHARES</th>
            <th className="text-right pb-2">UNREALIZED P&L</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((p) => (
            <tr key={p.symbol} className="border-b border-white/5">
              <td className="py-2">{p.symbol}</td>
              <td className="text-right py-2">{p.shares}</td>
              <td className={p.unrealizedPnL >= 0 ? "text-status-green text-right py-2" : "text-red-500 text-right py-2"}>
                {p.unrealizedPnL > 0 ? '+' : ''}{p.unrealizedPnL.toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
