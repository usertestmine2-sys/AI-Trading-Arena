import {useState} from 'react';
import {useMutation, useQueryClient} from '@tanstack/react-query';
import {placeOrder} from '@/src/api/arenaApi';
import {useArenaStore} from '@/src/store/useStore';

export default function OrderEntry() {
  const [symbol, setSymbol] = useState('');
  const [shares, setShares] = useState('');
  const queryClient = useQueryClient();
  const {addNotification} = useArenaStore();

  const mutation = useMutation({
    mutationFn: placeOrder,
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['positions']});
      addNotification({message: 'Order placed', type: 'success'});
    }
  });

  return (
    <div className="bg-bg-panel border border-border-glow rounded-xl p-5">
      <h3 className="font-bold uppercase text-sm mb-4">Order Entry</h3>
      <div className="space-y-3">
        <input className="w-full bg-bg-dark border border-border-glow rounded p-2 text-xs" placeholder="Symbol" value={symbol} onChange={e => setSymbol(e.target.value)} />
        <input className="w-full bg-bg-dark border border-border-glow rounded p-2 text-xs" type="number" placeholder="Shares" value={shares} onChange={e => setShares(e.target.value)} />
        <div className="grid grid-cols-2 gap-2">
            <button className="bg-status-green/20 text-status-green py-2 rounded text-xs font-bold" onClick={() => mutation.mutate({symbol, shares: Number(shares), price: 100, side: 'buy'})}>BUY</button>
            <button className="bg-red-500/20 text-red-500 py-2 rounded text-xs font-bold" onClick={() => mutation.mutate({symbol, shares: Number(shares), price: 100, side: 'sell'})}>SELL</button>
        </div>
      </div>
    </div>
  );
}
