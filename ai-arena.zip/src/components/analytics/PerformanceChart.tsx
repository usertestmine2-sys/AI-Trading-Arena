import {useQuery} from '@tanstack/react-query';
import {fetchEquityCurve} from '@/src/api/arenaApi';
import {ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid} from 'recharts';

export default function PerformanceChart() {
  const {data} = useQuery({queryKey: ['equity'], queryFn: fetchEquityCurve});

  return (
    <div className="bg-bg-panel border border-border-glow rounded-xl p-6 h-96">
      <h3 className="font-bold uppercase text-sm mb-6">Equity Curve</h3>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1f1f2e" />
          <XAxis dataKey="date" stroke="#a0a0ab" fontSize={10} />
          <YAxis stroke="#a0a0ab" fontSize={10} />
          <Tooltip contentStyle={{backgroundColor: '#0a0a0f', border: '1px solid #1f1f2e'}} />
          <Area type="monotone" dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
