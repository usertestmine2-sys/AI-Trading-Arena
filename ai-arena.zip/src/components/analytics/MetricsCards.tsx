import {useQuery} from '@tanstack/react-query';
import {fetchAnalyticsMetrics} from '@/src/api/arenaApi';

export default function MetricsCards() {
  const {data} = useQuery({queryKey: ['metrics'], queryFn: fetchAnalyticsMetrics});

  const cards = [
    {label: 'Win Rate', value: `${data?.winRate}%`},
    {label: 'Sharpe Ratio', value: data?.sharpeRatio.toFixed(2)},
    {label: 'Sortino Ratio', value: data?.sortinoRatio.toFixed(2)},
    {label: 'Drawdown', value: `${data?.drawdown}%`},
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {cards.map(c => (
        <div key={c.label} className="bg-bg-panel border border-border-glow p-6 rounded-xl text-center">
            <div className="text-xs text-text-secondary uppercase mb-2">{c.label}</div>
            <div className="text-2xl font-bold font-mono">{c.value}</div>
        </div>
      ))}
    </div>
  );
}
