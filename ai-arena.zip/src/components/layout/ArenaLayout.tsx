import {Outlet} from 'react-router-dom';
import TopNav from './TopNav';
import Sidebar from './Sidebar';
import RightPanel from './RightPanel';
import StatusBar from './StatusBar';
import NotificationCenter from '../notifications/NotificationCenter';

export default function ArenaLayout() {
  return (
    <div className="min-h-screen bg-bg-dark flex flex-col font-sans text-text-primary">
      <NotificationCenter />
      <TopNav />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 p-6 overflow-auto">
          <Outlet />
        </main>
        <RightPanel />
      </div>
      <StatusBar />
    </div>
  );
}
