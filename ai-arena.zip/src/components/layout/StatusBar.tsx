import {motion} from 'motion/react';

export default function StatusBar() {
  return (
    <motion.footer
      initial={{y: 20, opacity: 0}}
      animate={{y: 0, opacity: 1}}
      className="h-8 border-t border-border-glow bg-bg-dark flex items-center justify-between px-6 text-[10px] font-mono text-text-secondary uppercase tracking-widest"
    >
      <div className="flex gap-4">
        <span>System: Online</span>
        <span className="text-status-green">● Latency: 142ms</span>
      </div>
      <div>AI Arena OS // v1.0.0</div>
    </motion.footer>
  );
}
