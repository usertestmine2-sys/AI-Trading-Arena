import {LayoutDashboard, Brain, BarChart, History, Settings} from 'lucide-react';
import {motion} from 'motion/react';
import {NavLink} from 'react-router-dom';
import {cn} from '@/src/lib/utils';

const navItems = [
  {name: 'Dashboard', icon: LayoutDashboard, path: '/'},
  {name: 'Market', icon: BarChart, path: '/market'},
  {name: 'Strategies', icon: Brain, path: '/strategies'},
  {name: 'Paper Trading', icon: BarChart, path: '/paper-trading'},
  {name: 'Analytics', icon: BarChart, path: '/analytics'},
  {name: 'Models', icon: Brain, path: '/models'},
  {name: 'Arena Stats', icon: BarChart, path: '/stats'},
  {name: 'History', icon: History, path: '/history'},
  {name: 'Settings', icon: Settings, path: '/settings'},
];

export default function Sidebar() {
  return (
    <motion.aside
      initial={{x: -64, opacity: 0}}
      animate={{x: 0, opacity: 1}}
      className="w-64 border-r border-border-glow bg-bg-panel/30 flex flex-col p-4 gap-2"
    >
      {navItems.map((item) => (
        <NavLink
          key={item.name}
          to={item.path}
          className={({isActive}) =>
            cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
              isActive
                ? "bg-accent-purple/20 text-text-primary border border-accent-purple/30"
                : "text-text-secondary hover:bg-white/5 hover:text-text-primary"
            )
          }
        >
          <item.icon className="w-5 h-5" />
          <span className="font-medium">{item.name}</span>
        </NavLink>
      ))}
    </motion.aside>
  );
}
