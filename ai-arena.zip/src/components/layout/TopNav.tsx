import {Bell, User, Settings, Menu} from 'lucide-react';
import {motion} from 'motion/react';

export default function TopNav() {
  return (
    <motion.header
      initial={{y: -20, opacity: 0}}
      animate={{y: 0, opacity: 1}}
      className="h-16 border-b border-border-glow bg-bg-panel/50 backdrop-blur-md flex items-center justify-between px-6 z-50"
    >
      <div className="flex items-center gap-4">
        <button className="p-2 hover:bg-white/5 rounded transition-colors text-text-secondary">
          <Menu className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-bold uppercase tracking-widest text-text-primary">
          AI ARENA
        </h1>
      </div>
      <div className="flex items-center gap-4">
        <button className="p-2 hover:bg-white/5 rounded transition-colors text-text-secondary">
          <Bell className="w-5 h-5" />
        </button>
        <button className="p-2 hover:bg-white/5 rounded transition-colors text-text-secondary">
          <Settings className="w-5 h-5" />
        </button>
        <div className="w-8 h-8 rounded-full bg-accent-purple flex items-center justify-center text-white text-xs font-bold">
          <User className="w-4 h-4" />
        </div>
      </div>
    </motion.header>
  );
}
