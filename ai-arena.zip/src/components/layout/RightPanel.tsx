import {motion} from 'motion/react';
import {MessageSquare} from 'lucide-react';

export default function RightPanel() {
  return (
    <motion.aside
      initial={{x: 64, opacity: 0}}
      animate={{x: 0, opacity: 1}}
      className="w-80 border-l border-border-glow bg-bg-panel/30 flex flex-col"
    >
      <div className="p-4 border-b border-border-glow font-bold text-sm uppercase text-text-primary flex items-center gap-2">
        <MessageSquare className="w-4 h-4" />
        AI Assistant
      </div>
      <div className="flex-1 p-4 text-text-secondary text-sm italic">
        Arena analysis pending...
      </div>
    </motion.aside>
  );
}
