import {motion, AnimatePresence} from 'motion/react';
import {useArenaStore} from '@/src/store/useStore';
import {X} from 'lucide-react';
import {cn} from '@/src/lib/utils';

export default function NotificationCenter() {
  const {notifications, removeNotification} = useArenaStore();

  return (
    <div className="fixed top-20 right-6 z-[100] flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        {notifications.map((n) => (
          <motion.div
            key={n.id}
            initial={{opacity: 0, x: 20}}
            animate={{opacity: 1, x: 0}}
            exit={{opacity: 0, x: 20}}
            className={cn(
              "pointer-events-auto p-4 rounded-lg shadow-lg border flex items-center justify-between gap-4 w-72",
              n.type === 'info' ? "bg-bg-panel border-accent-cyan/30 text-accent-cyan" :
              n.type === 'success' ? "bg-bg-panel border-status-green/30 text-status-green" :
              "bg-bg-panel border-red-500/30 text-red-500"
            )}
          >
            <span className="text-sm font-medium">{n.message}</span>
            <button onClick={() => removeNotification(n.id)} className="hover:bg-white/10 p-1 rounded">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
