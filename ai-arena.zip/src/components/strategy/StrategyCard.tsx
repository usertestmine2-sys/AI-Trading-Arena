import {motion} from 'motion/react';
import React from 'react';
import {Strategy} from '@/src/types';
import {cn} from '@/src/lib/utils';
import {Settings, Play, Pause} from 'lucide-react';

interface Props {
  strategy: Strategy;
}

const StrategyCard: React.FC<Props> = ({strategy}) => {
  return (
    <motion.div
      initial={{opacity: 0, scale: 0.95}}
      animate={{opacity: 1, scale: 1}}
      className="bg-bg-panel border border-border-glow rounded-xl p-5 flex flex-col gap-4"
    >
      <div className="flex justify-between items-start">
        <h3 className="font-bold text-lg text-text-primary">{strategy.name}</h3>
        <button className={cn(
          "p-2 rounded transition-colors",
          strategy.isActive ? "bg-status-green/20 text-status-green" : "bg-white/5 text-text-secondary"
        )}>
          {strategy.isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </button>
      </div>
      
      <p className="text-xs text-text-secondary line-clamp-2">{strategy.description}</p>
      
      <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
        <div className="bg-bg-dark p-2 rounded">
          <div className="text-text-secondary">Win</div>
          <div className="text-text-primary">{strategy.winRate}%</div>
        </div>
        <div className="bg-bg-dark p-2 rounded">
          <div className="text-text-secondary">Risk</div>
          <div className="text-text-primary">{strategy.riskScore}</div>
        </div>
        <div className="bg-bg-dark p-2 rounded">
          <div className="text-text-secondary">Perf</div>
          <div className={strategy.performance >= 0 ? "text-status-green" : "text-red-500"}>
            {strategy.performance > 0 ? '+' : ''}{strategy.performance}%
          </div>
        </div>
      </div>

      <button className="w-full mt-auto py-2 bg-white/5 hover:bg-white/10 rounded flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider">
        <Settings className="w-4 h-4" /> Configure
      </button>
    </motion.div>
  );
}

export default StrategyCard;
