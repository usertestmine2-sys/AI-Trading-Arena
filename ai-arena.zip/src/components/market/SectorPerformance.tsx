import {useQuery} from '@tanstack/react-query';
import {fetchSectors} from '@/src/api/arenaApi';

export default function SectorPerformance() {
  const {data} = useQuery({queryKey: ['sectors'], queryFn: fetchSectors});

  return (
    <div className="bg-bg-panel border border-border-glow rounded-xl p-4">
      <h3 className="text-sm font-bold text-text-primary uppercase mb-4">Sector Performance</h3>
      <div className="space-y-2">
        {data?.map(s => (
          <div key={s.name} className="flex justify-between items-center text-xs">
            <span>{s.name}</span>
            <div className={s.performance >= 0 ? "text-status-green" : "text-red-500"}>
              {s.performance.toFixed(2)}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
