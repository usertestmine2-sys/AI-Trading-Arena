import {useQuery} from '@tanstack/react-query';
import {fetchMarketData} from '@/src/api/arenaApi';

export default function LivePriceTable() {
  const {data} = useQuery({queryKey: ['market'], queryFn: fetchMarketData, refetchInterval: 5000});

  return (
    <div className="bg-bg-panel border border-border-glow rounded-xl p-4">
      <h3 className="text-sm font-bold text-text-primary uppercase mb-4">Live Prices</h3>
      <table className="w-full text-xs font-mono">
        <thead>
          <tr className="text-text-secondary border-b border-border-glow">
            <th className="text-left pb-2">SYMBOL</th>
            <th className="text-right pb-2">PRICE</th>
            <th className="text-right pb-2">CHANGE</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((m) => (
            <tr key={m.symbol} className="border-b border-white/5">
              <td className="py-2">{m.symbol}</td>
              <td className="text-right py-2">{m.price.toFixed(2)}</td>
              <td className={m.change >= 0 ? "text-status-green text-right py-2" : "text-red-500 text-right py-2"}>
                {m.change > 0 ? '+' : ''}{m.change.toFixed(2)}%
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
