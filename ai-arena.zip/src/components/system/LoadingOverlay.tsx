import {motion} from 'motion/react';

export default function LoadingOverlay() {
  return (
    <motion.div
      initial={{opacity: 0}}
      animate={{opacity: 1}}
      exit={{opacity: 0}}
      className="fixed inset-0 z-[1000] flex items-center justify-center bg-bg-dark/80 backdrop-blur-sm"
    >
      <div className="w-12 h-12 border-4 border-accent-purple border-t-transparent rounded-full animate-spin" />
    </motion.div>
  );
}
